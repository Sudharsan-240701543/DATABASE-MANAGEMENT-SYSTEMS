import { supabase } from './supabaseClient';
import { Department, Employee, SalaryStructure, Payroll } from '../types';

// Helper function to handle Supabase query responses
const handleResponse = (response: { data: any, error: any }, errorMessage: string) => {
    if (response.error) {
        console.error(errorMessage, response.error);
        throw new Error(response.error.message);
    }
    return response.data;
};

// --- Employee APIs ---
export const getEmployees = async (): Promise<Employee[]> => {
    const response = await supabase.from('employees').select('*').order('emp_id');
    return handleResponse(response, 'Error fetching employees');
};

export const createEmployee = async (employee: Omit<Employee, 'emp_id'>): Promise<Employee> => {
    const response = await supabase.from('employees').insert(employee).select().single();
    return handleResponse(response, 'Error creating employee');
};

export const updateEmployee = async (updatedEmployee: Employee): Promise<Employee> => {
    const { emp_id, ...employeeData } = updatedEmployee;
    const response = await supabase.from('employees').update(employeeData).eq('emp_id', emp_id).select().single();
    return handleResponse(response, 'Error updating employee');
};

export const deleteEmployee = async (empId: number): Promise<{ success: boolean }> => {
    const response = await supabase.from('employees').delete().eq('emp_id', empId);
    handleResponse(response, 'Error deleting employee');
    return { success: true };
};

// --- Department APIs ---
export const getDepartments = async (): Promise<Department[]> => {
    // We use a database view 'departments_with_count' for efficiency
    const response = await supabase.from('departments_with_count').select('*').order('dept_id');
    return handleResponse(response, 'Error fetching departments');
};

export const createDepartment = async (department: Omit<Department, 'dept_id'>): Promise<Department> => {
    const response = await supabase.from('departments').insert(department).select().single();
    return handleResponse(response, 'Error creating department');
};

// --- Salary APIs ---
export const getSalaries = async (): Promise<SalaryStructure[]> => {
    const response = await supabase.from('salary_structures').select('*').order('structure_id');
    return handleResponse(response, 'Error fetching salaries');
};

export const createSalary = async (salary: Omit<SalaryStructure, 'structure_id'>): Promise<SalaryStructure> => {
    const response = await supabase.from('salary_structures').insert(salary).select().single();
    return handleResponse(response, 'Error creating salary');
};

export const updateSalary = async (updatedSalary: SalaryStructure): Promise<SalaryStructure> => {
    const { structure_id, ...salaryData } = updatedSalary;
    const response = await supabase.from('salary_structures').update(salaryData).eq('structure_id', structure_id).select().single();
    return handleResponse(response, 'Error updating salary');
};

// --- Payroll APIs ---
export const getPayrolls = async (): Promise<Payroll[]> => {
    const response = await supabase.from('payrolls').select('*').order('payroll_id');
    return handleResponse(response, 'Error fetching payrolls');
};

export const runPayroll = async (month: string, year: number): Promise<{ success: boolean; message: string }> => {
    const { data, error } = await supabase.rpc('run_payroll', { p_month: month, p_year: year });
    if (error) {
        console.error('Error running payroll:', error);
        throw new Error(error.message);
    }
    return { success: true, message: data };
};


// --- Dashboard/Reports APIs ---
export const getStats = async () => {
    const { data, error } = await supabase.rpc('get_dashboard_stats');
    if (error) {
        console.error('Error fetching stats:', error);
        throw new Error(error.message);
    }
    return data;
};

export const getDepartmentSalaryData = async () => {
    const { data, error } = await supabase.rpc('get_department_salary_distribution');
    if (error) {
        console.error('Error fetching department salary data:', error);
        throw new Error(error.message);
    }
    return data;
};
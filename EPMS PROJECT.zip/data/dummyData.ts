
import { Department, Employee, SalaryStructure, Payroll } from '../types';

export const initialDepartments: Department[] = [
  { dept_id: 1, dept_name: 'Technology' },
  { dept_id: 2, dept_name: 'Human Resources' },
  { dept_id: 3, dept_name: 'Finance' },
  { dept_id: 4, dept_name: 'Marketing' },
  { dept_id: 5, dept_name: 'Operations' },
];

export const initialEmployees: Employee[] = [
  { emp_id: 1, emp_name: 'Alice Johnson', email: 'alice.j@example.com', join_date: '2022-01-15', dept_id: 1 },
  { emp_id: 2, emp_name: 'Bob Williams', email: 'bob.w@example.com', join_date: '2021-11-20', dept_id: 1 },
  { emp_id: 3, emp_name: 'Charlie Brown', email: 'charlie.b@example.com', join_date: '2023-03-10', dept_id: 2 },
  { emp_id: 4, emp_name: 'Diana Miller', email: 'diana.m@example.com', join_date: '2022-08-05', dept_id: 3 },
  { emp_id: 5, emp_name: 'Ethan Davis', email: 'ethan.d@example.com', join_date: '2020-05-25', dept_id: 4 },
  { emp_id: 6, emp_name: 'Fiona Garcia', email: 'fiona.g@example.com', join_date: '2023-01-30', dept_id: 5 },
  { emp_id: 7, emp_name: 'George Rodriguez', email: 'george.r@example.com', join_date: '2022-07-12', dept_id: 1 },
  { emp_id: 8, emp_name: 'Hannah Martinez', email: 'hannah.m@example.com', join_date: '2021-09-01', dept_id: 3 },
  { emp_id: 9, emp_name: 'Ian Hernandez', email: 'ian.h@example.com', join_date: '2023-05-18', dept_id: 4 },
  { emp_id: 10, emp_name: 'Jane Lopez', email: 'jane.l@example.com', join_date: '2022-02-22', dept_id: 2 },
];

export const initialSalaryStructures: SalaryStructure[] = [
  { structure_id: 1, emp_id: 1, basic_salary: 60000, hra: 24000, allowance: 5000, deductions: 3000 },
  { structure_id: 2, emp_id: 2, basic_salary: 75000, hra: 30000, allowance: 6000, deductions: 4000 },
  { structure_id: 3, emp_id: 3, basic_salary: 45000, hra: 18000, allowance: 3000, deductions: 2000 },
  { structure_id: 4, emp_id: 4, basic_salary: 80000, hra: 32000, allowance: 7000, deductions: 5000 },
  { structure_id: 5, emp_id: 5, basic_salary: 55000, hra: 22000, allowance: 4000, deductions: 2500 },
  { structure_id: 6, emp_id: 6, basic_salary: 50000, hra: 20000, allowance: 3500, deductions: 2200 },
  { structure_id: 7, emp_id: 7, basic_salary: 90000, hra: 36000, allowance: 8000, deductions: 6000 },
  { structure_id: 8, emp_id: 8, basic_salary: 85000, hra: 34000, allowance: 7500, deductions: 5500 },
  { structure_id: 9, emp_id: 9, basic_salary: 58000, hra: 23200, allowance: 4200, deductions: 2800 },
  { structure_id: 10, emp_id: 10, basic_salary: 48000, hra: 19200, allowance: 3200, deductions: 2100 },
];

export const initialPayrolls: Payroll[] = [
  { payroll_id: 1, emp_id: 1, month: 'June', year: 2024, gross_salary: 89000, net_salary: 86000, generated_date: '2024-07-01' },
  { payroll_id: 2, emp_id: 2, month: 'June', year: 2024, gross_salary: 111000, net_salary: 107000, generated_date: '2024-07-01' },
  { payroll_id: 3, emp_id: 3, month: 'June', year: 2024, gross_salary: 66000, net_salary: 64000, generated_date: '2024-07-01' },
];

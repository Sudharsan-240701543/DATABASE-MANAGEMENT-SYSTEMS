
import React from 'react';
import { HashRouter, Routes, Route, Outlet, NavLink, useLocation } from 'react-router-dom';
import { Home, Users, Building2, Wallet, FileText, BarChart2, Menu, X } from 'lucide-react';

import { Dashboard } from './components/pages/Dashboard';
import { Employees } from './components/pages/Employees';
import { Departments } from './components/pages/Departments';
import { Salaries } from './components/pages/Salaries';
import { PayrollPage } from './components/pages/PayrollPage';
import { Reports } from './components/pages/Reports';
import { DataProvider } from './context/DataContext';

const navItems = [
  { path: '/', label: 'Dashboard', icon: Home },
  { path: '/employees', label: 'Employees', icon: Users },
  { path: '/departments', label: 'Departments', icon: Building2 },
  { path: '/salaries', label: 'Salaries', icon: Wallet },
  { path: '/payroll', label: 'Payroll', icon: FileText },
  { path: '/reports', label: 'Reports', icon: BarChart2 },
];

const Sidebar: React.FC = () => {
  return (
    <nav className="p-4 flex flex-col space-y-2">
      <h2 className="text-xl font-bold text-white mb-4 px-2">Payroll System</h2>
      {navItems.map((item) => (
        <NavLink
          key={item.path}
          to={item.path}
          className={({ isActive }) =>
            `flex items-center p-2 rounded-lg transition-colors ${
              isActive
                ? 'bg-green-600 text-white'
                : 'text-gray-300 hover:bg-gray-700 hover:text-white'
            }`
          }
        >
          <item.icon className="h-5 w-5 mr-3" />
          <span>{item.label}</span>
        </NavLink>
      ))}
    </nav>
  );
};

const Header: React.FC<{ onMenuClick: () => void }> = ({ onMenuClick }) => {
    const location = useLocation();
    const currentNavItem = navItems.find(item => item.path === location.pathname);
    const title = currentNavItem ? currentNavItem.label : 'Dashboard';

    return (
        <header className="bg-white dark:bg-gray-800 shadow-md p-4 flex items-center justify-between">
            <button onClick={onMenuClick} className="lg:hidden text-gray-600 dark:text-gray-300">
                <Menu className="h-6 w-6" />
            </button>
            <h1 className="text-2xl font-semibold text-gray-800 dark:text-white">{title}</h1>
            <div>
              <img src={`https://picsum.photos/40/40`} alt="User Avatar" className="rounded-full" />
            </div>
        </header>
    );
};


const MainLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900">
      {/* Mobile Sidebar Overlay */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden transition-opacity ${sidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setSidebarOpen(false)}
      ></div>
      
      {/* Sidebar */}
      <aside className={`fixed lg:relative inset-y-0 left-0 w-64 bg-gray-800 dark:bg-gray-900 shadow-lg transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 ease-in-out z-30`}>
        <div className="flex justify-end p-2 lg:hidden">
            <button onClick={() => setSidebarOpen(false)} className="text-white">
                <X className="h-6 w-6" />
            </button>
        </div>
        <Sidebar />
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 dark:bg-gray-900 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};


const App: React.FC = () => {
  return (
    <DataProvider>
      <HashRouter>
        <Routes>
          <Route path="/" element={<MainLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="employees" element={<Employees />} />
            <Route path="departments" element={<Departments />} />
            <Route path="salaries" element={<Salaries />} />
            <Route path="payroll" element={<PayrollPage />} />
            <Route path="reports" element={<Reports />} />
          </Route>
        </Routes>
      </HashRouter>
    </DataProvider>
  );
};

export default App;

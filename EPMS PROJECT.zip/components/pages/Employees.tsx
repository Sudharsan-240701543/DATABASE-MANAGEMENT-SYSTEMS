import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Employee } from '../../types';
import { Card, Spinner } from '../ui/Card';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';

const EmployeeForm: React.FC<{
  employee?: Employee | null;
  onSave: (employee: Employee | Omit<Employee, 'emp_id'>) => Promise<void>;
  onCancel: () => void;
}> = ({ employee, onSave, onCancel }) => {
  const { departments, loading } = useData();
  const [formData, setFormData] = useState({
    emp_name: employee?.emp_name || '',
    email: employee?.email || '',
    join_date: employee?.join_date ? new Date(employee.join_date).toISOString().split('T')[0] : '',
    dept_id: employee?.dept_id || departments[0]?.dept_id || 0,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'dept_id' ? parseInt(value) : value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const dataToSave = {
        ...formData,
        join_date: new Date(formData.join_date).toISOString()
    };
    if (employee) {
      await onSave({ ...employee, ...dataToSave });
    } else {
      await onSave(dataToSave);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
      <Card className="w-full max-w-lg">
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">{employee ? 'Edit Employee' : 'Add Employee'}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
            <input type="text" name="emp_name" value={formData.emp_name} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Join Date</label>
            <input type="date" name="join_date" value={formData.join_date} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Department</label>
            <select name="dept_id" value={formData.dept_id} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form}>
              {departments.map(dept => (
                <option key={dept.dept_id} value={dept.dept_id}>{dept.dept_name}</option>
              ))}
            </select>
          </div>
          <div className="flex justify-end space-x-2">
            <button type="button" onClick={onCancel} className="px-4 py-2 rounded-md bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200" disabled={loading.form}>Cancel</button>
            <button type="submit" className="px-4 py-2 rounded-md bg-green-600 text-white flex items-center" disabled={loading.form}>
              {loading.form && <Spinner />}
              Save
            </button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export const Employees: React.FC = () => {
  const { employees, deleteEmployee, addEmployee, updateEmployee, getDepartmentName, loading, error } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);

  const handleSave = async (employee: Employee | Omit<Employee, 'emp_id'>) => {
    if ('emp_id' in employee) {
      await updateEmployee(employee);
    } else {
      await addEmployee(employee);
    }
    setIsModalOpen(false);
    setEditingEmployee(null);
  };
  
  const handleDelete = async (empId: number) => {
    if(window.confirm('Are you sure you want to delete this employee? This will also remove their salary and payroll records.')) {
      await deleteEmployee(empId);
    }
  }

  return (
    <Card>
       <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Employees</h2>
        <button onClick={() => { setEditingEmployee(null); setIsModalOpen(true); }} className="flex items-center px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700">
            <PlusCircle className="h-5 w-5 mr-2" />
            Add Employee
        </button>
      </div>

      {error && <div className="p-4 mb-4 rounded-md text-white bg-red-500">{error}</div>}

      {loading.page ? <Spinner className="my-10" /> : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Department</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Join Date</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {employees.map(employee => (
                <tr key={employee.emp_id} className={loading.table ? 'opacity-50' : ''}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{employee.emp_name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{employee.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{getDepartmentName(employee.dept_id)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{new Date(employee.join_date).toLocaleDateString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                    <button onClick={() => { setEditingEmployee(employee); setIsModalOpen(true); }} className="text-indigo-600 hover:text-indigo-900" disabled={loading.table}><Edit className="h-5 w-5"/></button>
                    <button onClick={() => handleDelete(employee.emp_id)} className="text-red-600 hover:text-red-900" disabled={loading.table}><Trash2 className="h-5 w-5"/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {isModalOpen && <EmployeeForm employee={editingEmployee} onSave={handleSave} onCancel={() => { setIsModalOpen(false); setEditingEmployee(null); }} />}
    </Card>
  );
};

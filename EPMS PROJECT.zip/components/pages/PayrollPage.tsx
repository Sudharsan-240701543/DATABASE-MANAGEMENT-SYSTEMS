import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Card, Spinner } from '../ui/Card';
import { PlayCircle, Eye } from 'lucide-react';
import { Payroll } from '../../types';

const PayslipModal: React.FC<{ payroll: Payroll; onClose: () => void }> = ({ payroll, onClose }) => {
    const { getEmployeeName, getDepartmentName, employees, salaries } = useData();
    const employee = employees.find(e => e.emp_id === payroll.emp_id);
    const salary = salaries.find(s => s.emp_id === payroll.emp_id);
    if(!employee || !salary) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <Card className="w-full max-w-2xl relative">
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-gray-800 dark:text-gray-400 dark:hover:text-white">&times;</button>
                <div className="border-b pb-4 mb-4">
                    <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-white">Payslip</h2>
                    <p className="text-center text-gray-600 dark:text-gray-300">{payroll.month} {payroll.year}</p>
                </div>
                <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                        <p><strong>Employee Name:</strong> {getEmployeeName(payroll.emp_id)}</p>
                        <p><strong>Department:</strong> {getDepartmentName(employee.dept_id)}</p>
                    </div>
                    <div className="text-right">
                        <p><strong>Generated on:</strong> {new Date(payroll.generated_date).toLocaleDateString()}</p>
                    </div>
                </div>
                <div className="grid grid-cols-2 gap-8">
                    <div>
                        <h3 className="text-lg font-semibold mb-2 border-b pb-1 text-green-600">Earnings</h3>
                        <div className="flex justify-between"><p>Basic Salary:</p><span>${salary.basic_salary.toLocaleString()}</span></div>
                        <div className="flex justify-between"><p>HRA:</p><span>${salary.hra.toLocaleString()}</span></div>
                        <div className="flex justify-between"><p>Allowance:</p><span>${salary.allowance.toLocaleString()}</span></div>
                        <div className="flex justify-between font-bold mt-2 border-t pt-1"><p>Gross Salary:</p><span>${payroll.gross_salary.toLocaleString()}</span></div>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold mb-2 border-b pb-1 text-red-600">Deductions</h3>
                        <div className="flex justify-between"><p>Deductions:</p><span>${salary.deductions.toLocaleString()}</span></div>
                        <div className="flex justify-between font-bold mt-2 border-t pt-1"><p>Total Deductions:</p><span>${salary.deductions.toLocaleString()}</span></div>
                    </div>
                </div>
                <div className="mt-6 border-t-2 pt-4 text-center">
                    <p className="text-xl font-bold">Net Salary: <span className="text-green-600">${payroll.net_salary.toLocaleString()}</span></p>
                </div>
            </Card>
        </div>
    );
};

export const PayrollPage: React.FC = () => {
  const { payrolls, runPayroll, getEmployeeName, loading, error, clearError } = useData();
  const [month, setMonth] = useState('July');
  const [year, setYear] = useState(2024);
  const [notification, setNotification] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [selectedPayslip, setSelectedPayslip] = useState<Payroll | null>(null);

  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const years = [2023, 2024, 2025];

  const handleRunPayroll = async () => {
    clearError();
    setNotification(null);
    const result = await runPayroll(month, year);
    setNotification({ type: result.success ? 'success' : 'error', message: result.message });
    setTimeout(() => setNotification(null), 5000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">Run Payroll</h2>
        {notification && (
            <div className={`p-4 mb-4 rounded-md text-white ${notification.type === 'success' ? 'bg-green-500' : 'bg-red-500'}`}>
                {notification.message}
            </div>
        )}
        <div className="flex flex-col md:flex-row gap-4 items-end">
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Month</label>
                <select value={month} onChange={e => setMonth(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form}>
                    {months.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Year</label>
                <select value={year} onChange={e => setYear(parseInt(e.target.value))} className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form}>
                    {years.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
            </div>
            <button onClick={handleRunPayroll} className="flex items-center justify-center px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700 w-full md:w-auto" disabled={loading.form}>
                {loading.form ? <Spinner /> : <><PlayCircle className="h-5 w-5 mr-2" /> Run Payroll</>}
            </button>
        </div>
      </Card>

      <Card>
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">Payroll Records</h2>
        {loading.page ? <Spinner /> : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Employee</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Month/Year</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Gross Salary</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Net Salary</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {[...payrolls].reverse().map(p => (
                <tr key={p.payroll_id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{getEmployeeName(p.emp_id)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{p.month} {p.year}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">${p.gross_salary.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">${p.net_salary.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                     <button onClick={() => setSelectedPayslip(p)} className="text-indigo-600 hover:text-indigo-900 flex items-center ml-auto">
                        <Eye className="h-5 w-5 mr-1"/> View
                     </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        )}
      </Card>
      {selectedPayslip && <PayslipModal payroll={selectedPayslip} onClose={() => setSelectedPayslip(null)} />}
    </div>
  );
};

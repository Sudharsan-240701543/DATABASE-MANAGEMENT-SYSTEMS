import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { Card, Spinner } from '../ui/Card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export const Reports: React.FC = () => {
  const { payrolls, employees, getDepartmentName, loading } = useData();
  
  const uniquePayMonths = useMemo(() => {
    const unique = new Set(payrolls.map(p => `${p.month} ${p.year}`));
    return Array.from(unique).sort((a,b) => new Date(b).getTime() - new Date(a).getTime());
  }, [payrolls]);
  
  const [selectedMonth, setSelectedMonth] = useState(uniquePayMonths[0] || '');

  const filteredPayrolls = useMemo(() => {
    if (!selectedMonth) return [];
    const [month, year] = selectedMonth.split(' ');
    return payrolls.filter(p => p.month === month && p.year === parseInt(year));
  }, [selectedMonth, payrolls]);

  const monthlySummary = useMemo(() => {
    const totalEmployees = filteredPayrolls.length;
    const totalGross = filteredPayrolls.reduce((sum, p) => sum + p.gross_salary, 0);
    const totalNet = filteredPayrolls.reduce((sum, p) => sum + p.net_salary, 0);
    return { totalEmployees, totalGross, totalNet };
  }, [filteredPayrolls]);
  
  const departmentData = useMemo(() => {
    const data: { [key: string]: { gross: number, net: number, count: number } } = {};
    
    filteredPayrolls.forEach(payroll => {
        const employee = employees.find(e => e.emp_id === payroll.emp_id);
        if (employee) {
            const deptName = getDepartmentName(employee.dept_id);
            if (!data[deptName]) {
                data[deptName] = { gross: 0, net: 0, count: 0 };
            }
            data[deptName].gross += payroll.gross_salary;
            data[deptName].net += payroll.net_salary;
            data[deptName].count++;
        }
    });

    return Object.entries(data).map(([name, values]) => ({
      name,
      ...values,
    }));
  }, [filteredPayrolls, employees, getDepartmentName]);

  if(loading.page) {
    return <Spinner className="mt-20"/>
  }

  return (
    <div className="space-y-6">
        <Card>
            <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Payroll Reports</h2>
                <div>
                     <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Select Month</label>
                     <select value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        {uniquePayMonths.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                </div>
            </div>
        </Card>

        {!selectedMonth ? <Card><p>No payroll records found to generate reports.</p></Card> : (
            <>
                <Card>
                    <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Monthly Summary for {selectedMonth}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                        <div className="p-4 bg-green-100 dark:bg-green-900 rounded-lg">
                            <p className="text-sm text-green-600 dark:text-green-300">Employees Paid</p>
                            <p className="text-2xl font-bold text-green-800 dark:text-green-100">{monthlySummary.totalEmployees}</p>
                        </div>
                        <div className="p-4 bg-teal-100 dark:bg-teal-900 rounded-lg">
                            <p className="text-sm text-teal-600 dark:text-teal-300">Total Gross Salary</p>
                            <p className="text-2xl font-bold text-teal-800 dark:text-teal-100">${monthlySummary.totalGross.toLocaleString()}</p>
                        </div>
                        <div className="p-4 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
                            <p className="text-sm text-yellow-600 dark:text-yellow-300">Total Net Salary</p>
                            <p className="text-2xl font-bold text-yellow-800 dark:text-yellow-100">${monthlySummary.totalNet.toLocaleString()}</p>
                        </div>
                    </div>
                </Card>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                        <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Department-wise Salary (Gross)</h3>
                        <ResponsiveContainer width="100%" height={300}>
                            <BarChart data={departmentData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip formatter={(value: number) => `$${value.toLocaleString()}`} />
                                <Legend />
                                <Bar dataKey="gross" fill="#8884d8" name="Gross Salary" />
                            </BarChart>
                        </ResponsiveContainer>
                    </Card>
                     <Card>
                        <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Employee Distribution by Department</h3>
                        <ResponsiveContainer width="100%" height={300}>
                            <PieChart>
                                <Pie data={departmentData} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
                                {departmentData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                                </Pie>
                                <Tooltip formatter={(value, name) => [`${value} employees`, name]}/>
                                <Legend />
                            </PieChart>
                        </ResponsiveContainer>
                    </Card>
                </div>
            </>
        )}
    </div>
  );
};

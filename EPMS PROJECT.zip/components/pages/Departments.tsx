import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Card, Spinner } from '../ui/Card';
import { PlusCircle } from 'lucide-react';

export const Departments: React.FC = () => {
  const { departments, addDepartment, loading, error } = useData();
  const [newDeptName, setNewDeptName] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newDeptName.trim()) {
      try {
        await addDepartment({ dept_name: newDeptName.trim() });
        setNewDeptName('');
      } catch (err) {
        // Error is handled in context, but you could add specific logic here
        console.error("Failed to add department");
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <Card>
          <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">Add Department</h2>
           {error && <div className="p-2 mb-4 rounded-md text-white bg-red-500 text-sm">{error}</div>}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Department Name</label>
              <input 
                type="text" 
                value={newDeptName}
                onChange={(e) => setNewDeptName(e.target.value)}
                required 
                className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                disabled={loading.form}
              />
            </div>
            <button type="submit" className="w-full flex justify-center items-center px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700" disabled={loading.form}>
              {loading.form ? <Spinner /> : <><PlusCircle className="h-5 w-5 mr-2" />Add Department</>}
            </button>
          </form>
        </Card>
      </div>
      <div className="lg:col-span-2">
        <Card>
          <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">All Departments</h2>
          {loading.page ? <Spinner /> : (
           <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Department Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Employee Count</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {departments.map(dept => (
                  <tr key={dept.dept_id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{dept.dept_name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{dept.employee_count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          )}
        </Card>
      </div>
    </div>
  );
};
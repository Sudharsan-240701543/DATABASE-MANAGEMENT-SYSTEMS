import React, { useState, useMemo } from 'react';
import { useData } from '../../context/DataContext';
import { SalaryStructure } from '../../types';
import { Card, Spinner } from '../ui/Card';
import { PlusCircle, Edit } from 'lucide-react';

const SalaryForm: React.FC<{
  salary?: SalaryStructure | null;
  selectedEmpId?: number;
  onSave: (salary: SalaryStructure | Omit<SalaryStructure, 'structure_id'>) => Promise<void>;
  onCancel: () => void;
}> = ({ salary, selectedEmpId, onSave, onCancel }) => {
  const { employees, salaries, loading } = useData();
  const [formData, setFormData] = useState({
    emp_id: salary?.emp_id || selectedEmpId || 0,
    basic_salary: salary?.basic_salary || 0,
    hra: salary?.hra || 0,
    allowance: salary?.allowance || 0,
    deductions: salary?.deductions || 0,
  });
  
  const employeesWithoutSalary = useMemo(() => {
    return employees.filter(e => !salaries.some(s => s.emp_id === e.emp_id));
  }, [employees, salaries]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: parseFloat(value) }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (salary) {
      await onSave({ ...salary, ...formData });
    } else {
      await onSave(formData);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
      <Card className="w-full max-w-lg">
        <h2 className="text-2xl font-bold mb-4 text-gray-800 dark:text-white">{salary ? 'Edit Salary' : 'Add Salary'}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          {!salary && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Employee</label>
              <select name="emp_id" value={formData.emp_id} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form}>
                <option value={0} disabled>Select Employee</option>
                {employeesWithoutSalary.map(emp => (
                  <option key={emp.emp_id} value={emp.emp_id}>{emp.emp_name}</option>
                ))}
              </select>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Basic Salary</label>
            <input type="number" name="basic_salary" value={formData.basic_salary} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form} />
          </div>
           <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">HRA</label>
            <input type="number" name="hra" value={formData.hra} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form} />
          </div>
           <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Allowance</label>
            <input type="number" name="allowance" value={formData.allowance} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form} />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Deductions</label>
            <input type="number" name="deductions" value={formData.deductions} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 dark:bg-gray-700 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" disabled={loading.form} />
          </div>
          <div className="flex justify-end space-x-2">
            <button type="button" onClick={onCancel} className="px-4 py-2 rounded-md bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200" disabled={loading.form}>Cancel</button>
            <button type="submit" className="px-4 py-2 rounded-md bg-green-600 text-white" disabled={loading.form}>
              {loading.form ? <Spinner/> : 'Save'}
            </button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export const Salaries: React.FC = () => {
  const { salaries, addSalary, updateSalary, getEmployeeName, employees, loading, error } = useData();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSalary, setEditingSalary] = useState<SalaryStructure | null>(null);

  const handleSave = async (salary: SalaryStructure | Omit<SalaryStructure, 'structure_id'>) => {
    if ('structure_id' in salary) {
      await updateSalary(salary);
    } else {
      await addSalary(salary);
    }
    setIsModalOpen(false);
    setEditingSalary(null);
  };

  const employeesWithSalary = useMemo(() => {
    return employees.filter(e => salaries.some(s => s.emp_id === e.emp_id));
  }, [employees, salaries]);

  return (
    <Card>
       <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Salary Structures</h2>
        <button onClick={() => { setEditingSalary(null); setIsModalOpen(true); }} className="flex items-center px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700">
            <PlusCircle className="h-5 w-5 mr-2" />
            Add Salary
        </button>
      </div>

      {error && <div className="p-4 mb-4 rounded-md text-white bg-red-500">{error}</div>}

      {loading.page ? <Spinner className="my-10"/> : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Employee</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Basic Salary</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">HRA</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Allowance</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Deductions</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {employeesWithSalary.map(emp => {
                  const salary = salaries.find(s => s.emp_id === emp.emp_id);
                  if (!salary) return null;
                  return (
                      <tr key={salary.structure_id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{getEmployeeName(salary.emp_id)}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">${salary.basic_salary.toLocaleString()}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">${salary.hra.toLocaleString()}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">${salary.allowance.toLocaleString()}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">${salary.deductions.toLocaleString()}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button onClick={() => { setEditingSalary(salary); setIsModalOpen(true); }} className="text-indigo-600 hover:text-indigo-900"><Edit className="h-5 w-5"/></button>
                          </td>
                      </tr>
                  )
              })}
            </tbody>
          </table>
        </div>
      )}

      {isModalOpen && <SalaryForm salary={editingSalary} onSave={handleSave} onCancel={() => { setIsModalOpen(false); setEditingSalary(null); }} />}
    </Card>
  );
};

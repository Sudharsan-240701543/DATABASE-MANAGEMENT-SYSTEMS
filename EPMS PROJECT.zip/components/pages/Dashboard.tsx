import React, { useState, useEffect } from 'react';
import { useData } from '../../context/DataContext';
import { StatCard, Spinner } from '../ui/Card';
import { Users, Building2, Wallet, FileText } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import * as api from '../../utils/api';

interface Stats {
    totalEmployees: number;
    totalDepartments: number;
    totalNetSalary: number;
    lastPayrollRun: string;
}

interface DeptSalaryData {
    name: string;
    'Total Gross Salary': number;
}

export const Dashboard: React.FC = () => {
  const { loading: contextLoading } = useData();
  const [stats, setStats] = useState<Stats | null>(null);
  const [deptSalaryData, setDeptSalaryData] = useState<DeptSalaryData[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
        try {
            setLoading(true);
            const [statsData, salaryData] = await Promise.all([
                api.getStats(),
                api.getDepartmentSalaryData()
            ]);
            setStats(statsData);
            setDeptSalaryData(salaryData);
        } catch (error) {
            console.error("Failed to fetch dashboard data", error);
        } finally {
            setLoading(false);
        }
    };
    if(!contextLoading.page) {
       fetchData();
    }
  }, [contextLoading.page]);

  if (loading || contextLoading.page) {
    return <Spinner className="mt-20" />;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Total Employees" 
          value={stats?.totalEmployees ?? 0}
          icon={<Users className="h-6 w-6 text-white" />}
          color="bg-green-500"
        />
        <StatCard 
          title="Total Departments" 
          value={stats?.totalDepartments ?? 0}
          icon={<Building2 className="h-6 w-6 text-white" />}
          color="bg-teal-500"
        />
        <StatCard 
          title="Payroll (Net)"
          value={`$${stats?.totalNetSalary.toLocaleString() ?? 0}`}
          icon={<Wallet className="h-6 w-6 text-white" />}
          color="bg-yellow-500"
        />
        <StatCard 
          title="Last Payroll Run"
          value={stats?.lastPayrollRun ?? 'N/A'}
          icon={<FileText className="h-6 w-6 text-white" />}
          color="bg-red-500"
        />
      </div>
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
        <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Department-wise Salary Distribution</h3>
         <ResponsiveContainer width="100%" height={400}>
            <BarChart data={deptSalaryData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="Total Gross Salary" fill="#22c55e" />
            </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Department, Employee, SalaryStructure, Payroll } from '../types';
import * as api from '../utils/api';

interface LoadingState {
  page: boolean;
  table: boolean;
  form: boolean;
}

interface DataContextType {
  departments: Department[];
  employees: Employee[];
  salaries: SalaryStructure[];
  payrolls: Payroll[];
  loading: LoadingState;
  error: string | null;
  addEmployee: (employee: Omit<Employee, 'emp_id'>) => Promise<void>;
  updateEmployee: (employee: Employee) => Promise<void>;
  deleteEmployee: (empId: number) => Promise<void>;
  addDepartment: (department: Omit<Department, 'dept_id'>) => Promise<void>;
  addSalary: (salary: Omit<SalaryStructure, 'structure_id'>) => Promise<void>;
  updateSalary: (salary: SalaryStructure) => Promise<void>;
  runPayroll: (month: string, year: number) => Promise<{ success: boolean, message: string }>;
  getEmployeeName: (empId: number) => string;
  getDepartmentName: (deptId: number) => string;
  clearError: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [salaries, setSalaries] = useState<SalaryStructure[]>([]);
  const [payrolls, setPayrolls] = useState<Payroll[]>([]);
  const [loading, setLoading] = useState<LoadingState>({ page: true, table: false, form: false });
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);

  const getEmployeeName = useCallback((empId: number) => employees.find(e => e.emp_id === empId)?.emp_name || 'Unknown', [employees]);
  const getDepartmentName = useCallback((deptId: number) => departments.find(d => d.dept_id === deptId)?.dept_name || 'Unknown', [departments]);

  const fetchAllData = async () => {
    try {
      setLoading({ page: true, table: false, form: false });
      setError(null);
      const [empData, deptData, salaryData, payrollData] = await Promise.all([
        api.getEmployees(),
        api.getDepartments(),
        api.getSalaries(),
        api.getPayrolls()
      ]);
      setEmployees(empData);
      setDepartments(deptData);
      setSalaries(salaryData);
      setPayrolls(payrollData);
    } catch (err: any) {
      setError(err.message || 'Failed to load initial application data.');
      console.error(err);
    } finally {
      setLoading({ page: false, table: false, form: false });
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  const handleApiCall = async (call: () => Promise<any>, loadingType: keyof LoadingState = 'form') => {
    setLoading(prev => ({ ...prev, [loadingType]: true }));
    setError(null);
    try {
      await call();
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
      throw err; // Re-throw to be caught in component if needed
    } finally {
      setLoading(prev => ({ ...prev, [loadingType]: false }));
    }
  };

  const addEmployee = async (employee: Omit<Employee, 'emp_id'>) => {
    await handleApiCall(async () => {
      await api.createEmployee(employee);
      setEmployees(await api.getEmployees());
    });
  };
  
  const updateEmployee = async (updatedEmployee: Employee) => {
    await handleApiCall(async () => {
      await api.updateEmployee(updatedEmployee);
      setEmployees(await api.getEmployees());
    });
  };
  
  const deleteEmployee = async (empId: number) => {
    await handleApiCall(async () => {
      await api.deleteEmployee(empId);
      await fetchAllData(); // Refetch all data to ensure consistency after cascading delete
    }, 'table');
  };

  const addDepartment = async (department: Omit<Department, 'dept_id'>) => {
    await handleApiCall(async () => {
      await api.createDepartment(department);
      setDepartments(await api.getDepartments());
    });
  };
  
  const addSalary = async (salary: Omit<SalaryStructure, 'structure_id'>) => {
    await handleApiCall(async () => {
      await api.createSalary(salary);
      setSalaries(await api.getSalaries());
    });
  };

  const updateSalary = async (updatedSalary: SalaryStructure) => {
    await handleApiCall(async () => {
      await api.updateSalary(updatedSalary);
      setSalaries(await api.getSalaries());
    });
  };

  const runPayroll = async (month: string, year: number): Promise<{ success: boolean; message: string }> => {
    try {
      setLoading(prev => ({...prev, form: true}));
      setError(null);
      const result = await api.runPayroll(month, year);
      setPayrolls(await api.getPayrolls());
      return result;
    } catch (err: any) {
        const errorMessage = err.message || 'Failed to run payroll.';
        setError(errorMessage);
        return { success: false, message: errorMessage };
    } finally {
       setLoading(prev => ({...prev, form: false}));
    }
  };

  const value = {
    departments,
    employees,
    salaries,
    payrolls,
    loading,
    error,
    clearError,
    addEmployee,
    updateEmployee,
    deleteEmployee,
    addDepartment,
    addSalary,
    updateSalary,
    runPayroll,
    getEmployeeName,
    getDepartmentName
  };

  return (
    <DataContext.Provider value={value}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

export interface Department {
  dept_id: number;
  dept_name: string;
  employee_count?: number;
}

export interface Employee {
  emp_id: number;
  emp_name: string;
  email: string;
  join_date: string; // ISO string format
  dept_id: number;
}

export interface SalaryStructure {
  structure_id: number;
  emp_id: number;
  basic_salary: number;
  hra: number;
  allowance: number;
  deductions: number;
}

export interface Payroll {
  payroll_id: number;
  emp_id: number;
  month: string;
  year: number;
  gross_salary: number;
  net_salary: number;
  generated_date: string; // ISO string format
}